---
name: Executive Indigo Mobile Admin
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#464555'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#00524b'
  on-tertiary: '#ffffff'
  tertiary-container: '#006c63'
  on-tertiary-container: '#81eddf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 41px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.25rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system establishes a focused, high-clarity utility environment engineered for mobile administration, platform monitoring, and rapid executive action. Drawing equally from Apple Human Interface Guidelines (structural translucency, precision metrics, tactile touch targets) and Material Design 3 (dynamic tonal containers, expressive state layering, floating execution elements), the aesthetic balances clinical precision with modern visual drive.

The atmosphere is authoritative, quiet, and decisive. Grayscale surfaces remove visual static, letting dense system health indicators, event feeds, and configuration toggles surface naturally. The visual style merges Corporate Modernism with restrained Glassmorphism—relying on layered flat surfaces, crisp micro-borders, and targeted strikes of electric indigo for primary interaction points.

## Colors
The palette is built on strict functional contrast:

- **Primary Accent (`#4F46E5` Electric Indigo):** Reserved for primary interactive elements, active navigation routes, confirmed save actions, and floating action buttons.
- **Secondary Accent (`#2563EB` Bright Blue):** Used for deep links, analytical indicators, dynamic charts, and transient selection highlights.
- **Tertiary Accent (`#0D9488` Deep Teal):** Signals system health, uptime confirmations, and non-blocking background task completions.
- **Neutral Core (`#111827` Charcoal Slate):** Provides high-contrast legibility for titles and active icons. Canvas backgrounds rest on pure white (`#FFFFFF`) stepped down through subtle slate containers (`#F8FAFC`, `#F1F5F9`) framed by faint borders (`#E2E8F0`).
- **Semantic Feedback:** Critical alerts utilize `#DC2626` (Red), warnings utilize `#D97706` (Amber), and successes utilize `#16A34A` (Emerald).

## Typography
Typographic scale and hierarchy are tuned to native handheld scanning patterns. Inter delivers geometric clarity, tall x-height, and open counters necessary for rapid parsing of server status monitors, numerical KPIs, and dense audit tables.

- **Headlines:** Strictly tight-tracked to enhance authoritative structure on mobile viewports. `headline-xl` is reserved for large navigation collapsibles, while `headline-sm` anchors standard card headers.
- **Body:** Standardized around iOS body proportions (17px for primary list items, 15px for secondary content).
- **Labels & Microcopy:** Rendered with slight positive tracking and elevated weight (500–600) for timestamps, status chips, table column heads, and segmented controls.

## Layout & Spacing
The layout adheres to an 8pt base grid with an internal 4pt sub-grid for fine-grained icon-to-label alignment.

- **Canvas & Margin:** Default phone viewport utilizes a compact 16px (`1rem`) outer margin to maximize screen real estate for audit logs and form structures. Tablet viewports step to 20px (`1.25rem`).
- **Touch Targets:** Any interactive surface (buttons, select toggles, filter pills, row items) enforces a strict minimum footprint of 44×44pt, extending beyond visual bounds via transparent target padding where necessary.
- **Content Rhythm:** Containers stack with 12px or 16px gaps. Vertical rhythm within data cards stays compact (`space-xs` and `space-sm`) to ensure complete administrative modules fit comfortably above the fold.

## Elevation & Depth
Depth in the system is architectural, combining tonal surface shifts with diffused ambient lighting rather than heavy drop shadows:

- **Level 0 (Base Canvas):** Pure neutral `#FFFFFF` or sub-canvas `#F8FAFC`.
- **Level 1 (Cards, Grouped Insets, Table Rows):** `#FFFFFF` surfaces bounded by a crisp 1px perimeter border (`#E2E8F0`). Soft ambient lift: `0px 1px 3px rgba(17, 24, 39, 0.05)`.
- **Level 2 (Modals, Action Sheets, Context Menus):** Pure white container elevated above a dimmed scrim (`rgba(17, 24, 39, 0.4)`). Shadow: `0px 8px 24px -4px rgba(17, 24, 39, 0.12)`.
- **Level 3 (FABs, Active Floating Banners):** Electric indigo fill with color-tinted ambient glow: `0px 6px 20px rgba(79, 70, 229, 0.35)`.
- **Glass Elements (Navigation Bars & Tab Bars):** `rgba(255, 255, 255, 0.85)` surface with a 20px backdrop blur filter and a 1px border on the separating edge (`#E2E8F0`).

## Shapes
A dual-radius hierarchy defines component categories:

- **Cards & Primary Modules:** 12px to 16px corner radius (`rounded-lg` to `rounded-xl`), creating distinct, tactile boundaries for grouped admin content and chart modules.
- **Form Inputs & Control Pickers:** 8px to 10px corner radius (`rounded-md`), communicating structural utility and aligning with mobile keyboard accessories.
- **Buttons, Badges, and FABs:** Fully rounded pill shapes (`border-radius: 9999px`) provide contrast against rectangular cards, signaling immediate tap affordance.

## Components

### Buttons & FABs
- **Primary Button:** Full pill shape, filled `#4F46E5`, white text (`label-lg`), height 48px, minimum width 120px. 
- **Secondary Button:** Full pill shape, `#F1F5F9` background, `#111827` text, no border. Active state shifts to `#E2E8F0`.
- **Destructive Action:** Borderless or tinted red (`#FEE2E2` background, `#DC2626` text).
- **Floating Action Button (FAB):** Circular (56×56px) or extended pill (48px height) positioned 16px above the bottom tab bar, rendered in `#4F46E5` with tinted elevation.

### Input Fields & Controls
- **Text Inputs:** 48px height, 10px radius, `#FFFFFF` surface with 1px `#E2E8F0` border. Active focus shifts border to `#4F46E5` with a 2px outer glow (`rgba(79, 70, 229, 0.15)`). Trailing clear buttons and reveal triggers measure 44×44pt.
- **Switches & Segmented Controls:** Native iOS-style switches with an electric indigo active track (`#4F46E5`). Segmented controls feature an inset container (`#F1F5F9`) with an elevated white thumb indicator.
- **Checkboxes & Radios:** 20px bounding box, 6px radius for check indicators, 44×44pt hit slop. Indigo fill when checked.

### Cards & Grouped Containers
- Formed with 12px to 16px corner radii, `#FFFFFF` interior, 1px `#E2E8F0` hairline border, and Level 1 soft shadow.
- Inset grouping mirrors HIG list sections: titles sit outside the card as uppercase labels (`label-sm`), while list items inside the card are separated by inset divider lines (`1px solid #F1F5F9`).

### Timeline Logs & Audit Feeds
- Left-aligned 2px continuous vertical rule (`#E2E8F0`) with 10px node dots signaling event types (Indigo for deployments, Amber for updates, Red for outages).
- Monospaced timestamp tags (`label-sm`, `#64748B`) paired with high-contrast summary text (`body-sm`, `#111827`).

### Navigation & Tab Bar
- **Top Navigation Bar:** Integrated blur glass background, large title transition to centered inline title upon scrolling, right-hand actions formatted as 44pt borderless touch icons.
- **Bottom Tab Bar:** Fixed height (49pt + safe area inset), translucent frosted glass, active tab icons rendered in `#4F46E5` with 2pt badge indicators for unread alerts; inactive icons rendered in `#94A3B8`.